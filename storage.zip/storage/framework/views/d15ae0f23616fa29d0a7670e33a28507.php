<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Inventory</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            color: #333;
        }
        .hotel-info {
            background: #f4f4f4;
            padding: 10px;
            border-left: 5px solid #007bff;
            margin-bottom: 20px;
        }
        h2 {
            margin-top: 20px;
            color: #007bff;
        }
        ul {
            list-style-type: square;
            padding-left: 20px;
        }
        li {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>

    <h1>Items List for Hotel: <?php echo e($hotel->hotel_name); ?></h1>

    <div class="hotel-info">
        <p><strong>Address:</strong> <?php echo e($hotel->address); ?></p>
        <p><strong>Email:</strong> <?php echo e($hotel->email); ?></p>
        <p><strong>Contact No:</strong> <?php echo e($hotel->contact_no); ?></p>
        <p><strong>Website:</strong> <a href="<?php echo e($hotel->website); ?>" target="_blank"><?php echo e($hotel->website); ?></a></p>
        <p><strong>Description:</strong> <?php echo e($hotel->description); ?></p>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName => $categoryItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <h2><?php echo e($categoryName); ?></h2>
        <ul>
            <?php $__currentLoopData = $categoryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($item->name); ?> - <?php echo e($item->unit_name); ?> (<?php echo e($item->quantity); ?>)</li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No items found for this hotel.</p>
    <?php endif; ?>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\kitchen_inventory\resources\views/hotel_items_list.blade.php ENDPATH**/ ?>
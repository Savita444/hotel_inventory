<?php if(session('user_role') == '1'): ?>
<?php echo $__env->make('layouts.sidebar.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(session('user_role') == '2'): ?>
<?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(session('user_role') == '3'): ?>
<?php echo $__env->make('layouts.sidebar.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


<style>
     /* Loader Style */
     #custome_loader {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .spinner-border {
            width: 3rem;
            height: 3rem;
        }
    </style>

    <!-- Loader -->
<div id="custome_loader" style="display:none">
    <div class="spinner-border text-light" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

   <?php /**PATH D:\xampp\htdocs\kitchen_inventory\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>